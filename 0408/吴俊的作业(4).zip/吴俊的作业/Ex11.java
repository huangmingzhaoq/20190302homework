package newer.com.demo;
/**
 * ��:1!+2!+3!+......+10!
 * @author Administrator
 *
 */
public class Ex11 {

	public static void main(String[] args) {
	int sum=0;
	
	for(int i=1;i<=10;i++) {
		int fact=1;//����Ҫע��
		for(int j=1;j<=i;j++) {
			fact*=j;	
		}
		sum+=fact;
	}
	
	System.out.println("1!+2!+3!+......+10!�ĺ���"+sum);

	}

}
