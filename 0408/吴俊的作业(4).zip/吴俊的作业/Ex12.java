package newer.com.demo;
/**
 * ��̴�ӡ1000���ڵ�ˮ�ɻ���
 * @author Administrator
 *
 */
public class Ex12 {

	public static void main(String[] args) {
		for(int num=100;num<1000;num++) {
			int num1=num/100;
			int num2=num%100/10;
			int num3=num%10;
			
			if(num==num1*num1*num1+num2*num2*num2+num3*num3*num3) {
				System.out.println(num);
			}
		}
		

	}

}
